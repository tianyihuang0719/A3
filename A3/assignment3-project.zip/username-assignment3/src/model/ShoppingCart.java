// Finish and comment me!

package model;

import java.math.BigDecimal;

public class ShoppingCart {
    
    // Add whatever fields you think are necessary.


    public ShoppingCart() {

    }


    public void add(final Item theItem, final int theQuantity) {
        
    }


    public void setMembership(final boolean theMembership) {
        
    }


    public BigDecimal calculateTotal() {

        return null;
    }
    
    public void clear() {
        
    }

}
