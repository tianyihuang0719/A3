// Finish and comment me!

package model;

import java.math.BigDecimal;
import java.util.Objects;

public final class Item {
    
    // Add whatever fields you think are necessary.
    // Fields for item name, price, bulk quantity, and bulk price
    private final String name;
    private final BigDecimal price;
    private final int bulkQuantity;
    private final BigDecimal bulkPrice;
    
    /**
     * Constructor for an item with no bulk pricing.
     */
 
    public Item(final String theName, final BigDecimal thePrice) {
        if (theName == null || thePrice == null || thePrice.compareTo(BigDecimal.ZERO) < 0) {
            throw new IllegalArgumentException("Invalid name or price.");
        }
        this.name = theName;
        this.price = thePrice;
        this.bulkQuantity = 0;
        this.bulkPrice = null;      
    }

    /**
     * Constructor for an item with bulk pricing.
     */

    public Item(final String theName, final BigDecimal thePrice,
                final int theBulkQuantity, final BigDecimal theBulkPrice) {
        if (theName == null || thePrice == null || theBulkPrice == null || thePrice.compareTo(BigDecimal.ZERO) < 0
                || theBulkPrice.compareTo(BigDecimal.ZERO) < 0 || theBulkQuantity <= 0) {
            throw new IllegalArgumentException("Invalid parameters for bulk item.");
        }
        this.name = theName;
        this.price = thePrice;
        this.bulkQuantity = theBulkQuantity;
        this.bulkPrice = theBulkPrice;

    }
    
    /**
     * Returns the name of this item.
     */

    public String getName() {
        
        return name;
    }
    
    /**
     * Returns the price of this item.
     */
    
    public BigDecimal getPrice() {
        return price;
    }

    /**
     * Returns the bulk quantity for this item.
     */
    
    public int getBulkQuantity() {
        return bulkQuantity;
    }

    /**
     * Returns the bulk price for this item.
     */
    
    public BigDecimal getBulkPrice() {
        return bulkPrice;
    }

    /**
     * Returns true if this item has bulk pricing.
     */
    
    public boolean isBulk() {
        return bulkQuantity > 0 && bulkPrice != null;
    }

    /**
     * Returns a string representation of this item.
     * If the item has bulk pricing, the format is: "name, $price (bulkQuantity for $bulkPrice)"
     * If the item does not have bulk pricing, the format is: "name, $price"
     * return A string representation of the item.
     */

    @Override
    public String toString() {
        
        if (isBulk()) {
            return String.format("%s, $%.2f (%d for $%.2f)", name, price, bulkQuantity, bulkPrice);
        }
        return String.format("%s, $%.2f", name, price);
    }
    
    /**
     * Checks if this item is equal to another object.
     * Two items are considered equal if they have the same name, price, bulk quantity, and bulk price.
     * return True if the items are equal, false otherwise.
     */

    @Override
    public boolean equals(final Object theOther) {
        
        if (this == theOther) {
            return true;
        }
        if (!(theOther instanceof Item)) {
            return false;
        }
        final Item other = (Item) theOther;
        return Objects.equals(name, other.name)
                && Objects.equals(price, other.price)
                && bulkQuantity == other.bulkQuantity
                && Objects.equals(bulkPrice, other.bulkPrice);
    }


    @Override
    public int hashCode() {
        
        return Objects.hash(name, price, bulkQuantity, bulkPrice);
    }

}
