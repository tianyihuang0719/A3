// Finish and comment me!

package model;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.HashMap;
import java.util.Map;

public class ShoppingCart {
    
    // A map to store items and their quantities
    private final Map<Item, Integer> cartItems;
    private boolean hasMembership;  // Whether the customer has a membership

    /**
     * Constructor for ShoppingCart that initializes an empty cart.
     */

    public ShoppingCart() {
        cartItems = new HashMap<>();
        hasMembership = false;

    }
    
    /**
     * Adds an item to the shopping cart. If the item is already present, replaces the previous quantity with the new quantity.
     */

    public void add(final Item theItem, final int theQuantity) {
        if (theItem == null || theQuantity <= 0) {
            throw new IllegalArgumentException("Item cannot be null and "
                    + "quantity must be positive.");
        }
        // Replace or add the item with the new quantity
        cartItems.put(theItem, theQuantity);
        
    }
    
    /**
     * Sets whether the customer has a membership for discount purposes.
     */

    public void setMembership(final boolean theMembership) {
        hasMembership = theMembership;
        
    }
    
    /**
     * Calculates the total cost of all items in the cart.
     * If the item has bulk pricing and the quantity meets the bulk threshold, 
     * the bulk price is applied.
     * A membership discount (10%) is applied if the customer has membership.
     * The total is rounded to two decimal places using RoundingMode.HALF_EVEN.
     * return The total cost as a BigDecimal.
     */

    public BigDecimal calculateTotal() {

        BigDecimal total = BigDecimal.ZERO;

        // Iterate over each item and calculate total based on bulk pricing or regular pricing
        for (Map.Entry<Item, Integer> entry : cartItems.entrySet()) {
            final Item item = entry.getKey();
            final int quantity = entry.getValue();

            if (item.isBulk() && quantity >= item.getBulkQuantity()) {
                // Calculate bulk pricing
                final int bulkSets = quantity / item.getBulkQuantity();
                final int remainingItems = quantity % item.getBulkQuantity();
                final BigDecimal bulkTotal = item.getBulkPrice().multiply(BigDecimal.valueOf(bulkSets));
                final BigDecimal regularTotal = item.getPrice().multiply(BigDecimal.valueOf(remainingItems));

                total = total.add(bulkTotal).add(regularTotal);
            } else {
                // Calculate regular pricing
                final BigDecimal itemTotal = item.getPrice().multiply(BigDecimal.valueOf(quantity));
                total = total.add(itemTotal);
            }
        }

        // Apply membership discount (10%) if applicable
        if (hasMembership) {
            total = total.multiply(BigDecimal.valueOf(0.90));
        }

        // Return the total with two decimal places using RoundingMode.HALF_EVEN
        return total.setScale(2, RoundingMode.HALF_EVEN);
    }

    /**
     * Clears all the items in the shopping cart.
     */
    
    public void clear() {
        cartItems.clear();
        
    }

}
