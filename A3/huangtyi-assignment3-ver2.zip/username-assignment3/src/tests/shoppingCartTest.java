package tests;

import static org.junit.jupiter.api.Assertions.*;

import java.math.BigDecimal;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class shoppingCartTest {
   


    @BeforeEach
    void setUp() throws Exception {
        
    }

    @Test
    void testShoppingCart() {
        fail("Not yet implemented");
    }

    @Test
    void testAdd() {
        fail("Not yet implemented");
    }

    @Test
    void testSetMembership() {
        fail("Not yet implemented");
    }

    @Test
    void testCalculateTotal() {
        fail("Not yet implemented");
    }

    @Test
    void testClear() {
        fail("Not yet implemented");
    }

}
